import Database from '../database/database';
import jwt from 'jsonwebtoken';
import nodemailer from 'nodemailer';

class BankService {
	private db: Database;
	private databaseget: Database;
	constructor() {
		this.db = new Database();
		this.databaseget = new Database(true);
	}

	public async addBank(req: any): Promise<any> {		
		return this.db.query(`
			INSERT into
			bankdetails ( bankname, accountnumber, type, ifsccode, userId ) 
			VALUES (
				'${req.bankname}',
				'${req.accountnumber}',
				${req.type},
				'${req.ifsccode}',
				${req.userId}
			)
		`)
	};

	public async updateBank(req: any): Promise<any> {
		let text = '';
		const fields: any = [
			'bankname',
			'type',
			'accountnumber',
			'ifsccode',		
		];
		Object.keys(req).map((key) => {
			if (fields.indexOf(key) > -1) {
				if (typeof req[key] === 'string') {
					text += key + '="' + `${req[key]}` + '",';
				} else {
					text += key + '=' + `${req[key]}` + ',';
				}
			}
		});
		
		if (text && req.id) {
			text += ` updatedat = UTC_TIMESTAMP, updateduserid = ${req.userId}`;
			return this.db.query(`
				Update bankdetails
			SET
				${text}
			WHERE
				id = ${req.id}
		 	`);
		} else {
			return null
		}
	};

	public async getBankList(req: any): Promise<any> {
		return this.db.query(`
			SELECT b.id, b.bankname, bt.type, b.accountnumber, b.ifsccode
			FROM 
				bankdetails b                
			LEFT JOIN 
				banktypes bt 
			ON 
				b.type = bt.id
			WHERE 
				userId = ${req.personId}	
		`)
	};

	public async getBankData(bankId: number): Promise<any> {
		return this.db.query(`
		SELECT 
			b.id, b.bankname, b.type, b.accountnumber, b.ifsccode 
		FROM 
			bankdetails b 
		WHERE 
			b.id = ${bankId}	
		`)
	};

	public async create(): Promise<any> {
		const createDD = {
			bankTypes: await this.db.query(`
				SELECT b.id, b.type FROM banktypes b
			`)
		}
		return createDD;
	};
}

export default BankService;